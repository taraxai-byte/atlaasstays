import { openai } from "./openai";
import { env } from "./env";

export const travelPlanSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    destination: { type: ["string","null"] },
    checkIn: { type: ["string","null"] },
    checkOut: { type: ["string","null"] },
    travelers: { type: ["integer","null"] },
    budgetAmount: { type: ["number","null"] },
    budgetCurrency: { type: ["string","null"] },
    preferences: { type: "array", items: { type: "string" } },
    missingInformation: { type: "array", items: { type: "string" } },
    nextAction: { type: "string" },
    dataStatus: { type: "string" }
  },
  required: [
    "destination","checkIn","checkOut","travelers","budgetAmount",
    "budgetCurrency","preferences","missingInformation","nextAction","dataStatus"
  ]
} as const;

export async function analyzeTravelRequest(userRequest: string) {
  const response = await openai.responses.create({
    model: env().OPENAI_MODEL,
    input: [
      {
        role: "system",
        content:
          "You are Atlas AI, the travel intelligence layer of AtlasStays. " +
          "Extract travel requirements only. Never invent live prices, inventory, availability, reviews, suppliers or booking confirmations. " +
          "If verified data is unavailable, say so. Do not calculate a real booking total from imagination. " +
          "Return structured travel requirements and the next safe action."
      },
      { role: "user", content: userRequest }
    ],
    text: {
      format: {
        type: "json_schema",
        name: "atlas_travel_plan",
        strict: true,
        schema: travelPlanSchema
      }
    }
  });

  const text = response.output_text;
  if (!text) throw new Error("AI returned no structured output.");
  return JSON.parse(text);
}