import type { SupplierAdapter, SearchRequest, VerifiedOffer } from "./types";

const adapters: SupplierAdapter[] = [];

export function registerSupplier(adapter: SupplierAdapter) {
  adapters.push(adapter);
}

export async function searchVerifiedInventory(input: SearchRequest): Promise<VerifiedOffer[]> {
  const results = await Promise.all(adapters.map(async (adapter) => {
    try { return await adapter.search(input); }
    catch (error) { console.error("supplier_search_error", adapter.name, error); return []; }
  }));
  return results.flat().filter((x) => x.sourceVerified && x.available);
}
