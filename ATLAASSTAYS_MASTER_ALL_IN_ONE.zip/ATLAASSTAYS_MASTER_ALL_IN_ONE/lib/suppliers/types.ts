export type SearchRequest = {
  destination?: string;
  origin?: string;
  checkIn?: string;
  checkOut?: string;
  travelers?: number;
  currency?: string;
};

export type VerifiedOffer = {
  id: string;
  supplier: string;
  productType: "hotel" | "rental" | "flight" | "transfer" | "experience";
  name: string;
  price: number;
  currency: string;
  available: boolean;
  sourceVerified: boolean;
  metadata: Record<string, unknown>;
};

export interface SupplierAdapter {
  readonly name: string;
  search(input: SearchRequest): Promise<VerifiedOffer[]>;
  revalidate(offerId: string): Promise<VerifiedOffer>;
  book(offerId: string, customer: Record<string, unknown>): Promise<{
    confirmed: boolean;
    supplierReference?: string;
    metadata?: Record<string, unknown>;
  }>;
  cancel?(supplierReference: string): Promise<{ cancelled: boolean }>;
}
