import { z } from "zod";

export const conciergeRequestSchema = z.object({
  userRequest: z.string().trim().min(2).max(8000),
  userId: z.string().uuid().optional(),
  conversationId: z.string().uuid().optional()
});

export const checkoutRequestSchema = z.object({
  userId: z.string().uuid(),
  productType: z.enum(["hotel","rental","flight","transfer","experience"]),
  productId: z.string().uuid(),
  quantity: z.number().int().positive().max(20).default(1)
});