"use client";

import { useState } from "react";

type ConciergeResponse = {
  success?: boolean;
  conversationId?: string;
  message?: string;
  plan?: {
    destination?: string | null;
    dates?: { checkIn?: string | null; checkOut?: string | null };
    travelers?: number | null;
    budget?: { amount?: number | null; currency?: string | null };
    preferences?: string[];
    nextAction?: string;
    dataStatus?: string;
  };
  error?: string;
};

export default function Home() {
  const [request, setRequest] = useState("");
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<ConciergeResponse | null>(null);

  async function askAtlas() {
    if (!request.trim()) return;
    setLoading(true); setData(null);
    try {
      const res = await fetch("/api/ai/concierge", {
        method: "POST",
        headers: {"content-type":"application/json"},
        body: JSON.stringify({ userRequest: request })
      });
      setData(await res.json());
    } catch {
      setData({ error: "Atlas AI could not be reached. Please try again." });
    } finally { setLoading(false); }
  }

  return (
    <main className="shell">
      <nav className="nav">
        <div className="brand">ATLAASSTAYS<span className="gold">.</span></div>
        <div className="links">
          <a href="#hotels">Hotels</a><a href="#flights">Flights</a><a href="#rentals">Rentals</a>
          <a href="#transfers">Transfers</a><a href="#experiences">Experiences</a>
          <a href="#ai">Atlas AI</a>
        </div>
      </nav>

      <section className="hero" id="ai">
        <h1>Travel, <span className="gold">intelligently.</span></h1>
        <p>Discover stays, flights, transfers and experiences through one intelligent travel platform.</p>

        <div className="panel">
          <div className="search">
            <textarea
              value={request}
              onChange={e => setRequest(e.target.value)}
              placeholder="Where do you want to go? e.g. Find me a luxury hotel in Dubai for 4 nights under $1,000."
            />
            <button className="btn" disabled={loading || !request.trim()} onClick={askAtlas}>
              {loading ? "Thinking..." : "Ask Atlas AI"}
            </button>
          </div>

          {data && (
            <div className="result">
              {data.error ? <p>{data.error}</p> : (
                <>
                  <h3>Atlas AI</h3>
                  <p>{data.message}</p>
                  {data.plan && <pre style={{whiteSpace:"pre-wrap",color:"#c8c0b8"}}>
                    {JSON.stringify(data.plan, null, 2)}
                  </pre>}
                </>
              )}
            </div>
          )}
        </div>
      </section>

      <section className="grid">
        {["Hotels","Flights","Vacation Rentals","Airport Transfers","Experiences","My Trips"].map(x =>
          <div className="card" key={x}><h3>{x}</h3><p className="muted">Ready for verified inventory integration.</p></div>
        )}
      </section>
    </main>
  );
}