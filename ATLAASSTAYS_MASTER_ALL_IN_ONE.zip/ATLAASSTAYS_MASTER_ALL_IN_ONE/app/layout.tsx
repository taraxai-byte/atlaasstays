import "./globals.css";

export const metadata = {
  title: "AtlasStays — Travel, intelligently planned.",
  description: "AI-powered travel planning, stays, flights, transfers and experiences."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}