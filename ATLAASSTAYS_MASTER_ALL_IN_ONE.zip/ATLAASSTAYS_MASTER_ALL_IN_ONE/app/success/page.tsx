export default function Success() {
  return <main className="shell"><section className="hero"><h1>Payment <span className="gold">received.</span></h1><p>Your payment was received by Stripe. Final booking confirmation is driven by the verified webhook and booking workflow.</p></section></main>;
}