import { NextResponse } from "next/server";
import { z } from "zod";
import { searchVerifiedInventory } from "@/lib/suppliers/registry";

const schema = z.object({
  productType: z.enum(["hotel","rental","flight","transfer","experience"]),
  destination: z.string().trim().min(1).max(200).optional(),
  origin: z.string().trim().max(200).optional(),
  checkIn: z.string().optional(),
  checkOut: z.string().optional(),
  travelers: z.number().int().positive().max(50).optional(),
  currency: z.string().length(3).default("USD")
});

export async function POST(req: Request) {
  try {
    const input = schema.parse(await req.json());
    const offers = await searchVerifiedInventory(input);
    return NextResponse.json({
      success: true,
      liveInventoryConnected: offers.length > 0,
      results: offers
    });
  } catch {
    return NextResponse.json({ success: false, error: "Invalid search request." }, { status: 400 });
  }
}
