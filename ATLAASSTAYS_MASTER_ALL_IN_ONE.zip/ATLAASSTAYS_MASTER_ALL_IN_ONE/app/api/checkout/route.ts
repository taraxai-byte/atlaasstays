import { NextResponse } from "next/server";
import { checkoutRequestSchema } from "@/lib/validation";
import { sql } from "@/lib/db";
import { stripe } from "@/lib/stripe";
import { env } from "@/lib/env";

export async function POST(req: Request) {
  try {
    const input = checkoutRequestSchema.parse(await req.json());

    // IMPORTANT: The server obtains the price from verified application/supplier data.
    // Never accept a browser-supplied price.
    const rows = await sql`
      SELECT id, name, price_amount, currency, is_available
      FROM bookable_products
      WHERE id = ${input.productId}
        AND product_type = ${input.productType}
      LIMIT 1
    `;

    if (!rows.length || !rows[0].is_available) {
      return NextResponse.json({ error: "Product unavailable." }, { status: 409 });
    }

    const product = rows[0];
    const amount = Number(product.price_amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      return NextResponse.json({ error: "Invalid verified product price." }, { status: 500 });
    }

    const bookingRows = await sql`
      INSERT INTO bookings (
        customer_id, product_type, product_id, base_amount, total_amount,
        currency, payment_status, booking_status, idempotency_key
      )
      VALUES (
        ${input.userId}, ${input.productType}, ${input.productId},
        ${amount}, ${amount}, ${product.currency},
        'PENDING', 'PAYMENT_REQUIRED', ${crypto.randomUUID()}
      )
      RETURNING id
    `;

    const bookingId = bookingRows[0].id;

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: [{
        quantity: input.quantity,
        price_data: {
          currency: product.currency.toLowerCase(),
          unit_amount: Math.round(amount * 100),
          product_data: { name: String(product.name) }
        }
      }],
      metadata: { booking_id: String(bookingId) },
      success_url: `${env().NEXT_PUBLIC_APP_URL}/success?booking_id=${bookingId}`,
      cancel_url: `${env().NEXT_PUBLIC_APP_URL}/cancel?booking_id=${bookingId}`
    }, {
      idempotencyKey: `booking-${bookingId}`
    });

    await sql`
      INSERT INTO payments (
        booking_id, provider, provider_session_id, amount, currency, status
      )
      VALUES (
        ${bookingId}, 'stripe', ${session.id}, ${amount}, ${product.currency}, 'PENDING'
      )
    `;

    return NextResponse.json({ success: true, bookingId, paymentUrl: session.url });
  } catch (error) {
    console.error("checkout_error", error);
    return NextResponse.json({ error: "Checkout could not be created." }, { status: 400 });
  }
}