import { NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";
import { env } from "@/lib/env";
import { sql } from "@/lib/db";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const signature = req.headers.get("stripe-signature");
  if (!signature) return new NextResponse("Missing signature", { status: 400 });

  const body = await req.text();

  let event;
  try {
    event = stripe.webhooks.constructEvent(body, signature, env().STRIPE_WEBHOOK_SECRET);
  } catch {
    return new NextResponse("Invalid signature", { status: 400 });
  }

  try {
    const inserted = await sql`
      INSERT INTO payment_events (provider_event_id, event_type, payload)
      VALUES (${event.id}, ${event.type}, ${JSON.stringify(event)})
      ON CONFLICT (provider_event_id) DO NOTHING
      RETURNING id
    `;

    // Already processed: idempotent success.
    if (!inserted.length) return NextResponse.json({ received: true });

    if (event.type === "checkout.session.completed") {
      const session = event.data.object as any;
      const bookingId = session.metadata?.booking_id;
      if (!bookingId) throw new Error("Missing booking_id metadata.");

      await sql`
        UPDATE payments
        SET status = 'PAID', paid_at = NOW()
        WHERE provider_session_id = ${session.id}
      `;

      await sql`
        UPDATE bookings
        SET payment_status = 'PAID',
            booking_status = 'CONFIRMED',
            updated_at = NOW()
        WHERE id = ${bookingId}
      `;
    }

    if (event.type === "checkout.session.expired") {
      const session = event.data.object as any;
      const bookingId = session.metadata?.booking_id;
      if (bookingId) {
        await sql`
          UPDATE payments SET status = 'FAILED'
          WHERE provider_session_id = ${session.id}
        `;
        await sql`
          UPDATE bookings
          SET payment_status = 'FAILED',
              booking_status = 'FAILED',
              updated_at = NOW()
          WHERE id = ${bookingId}
        `;
      }
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error("stripe_webhook_error", error);
    return new NextResponse("Webhook processing failed", { status: 500 });
  }
}