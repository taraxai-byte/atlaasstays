import { NextResponse } from "next/server";
import { analyzeTravelRequest } from "@/lib/ai";
import { conciergeRequestSchema } from "@/lib/validation";
import { sql } from "@/lib/db";

export async function POST(req: Request) {
  try {
    const body = conciergeRequestSchema.parse(await req.json());
    const plan = await analyzeTravelRequest(body.userRequest);

    let conversationId = body.conversationId;

    if (!conversationId) {
      const rows = await sql`
        INSERT INTO conversations (user_id, title)
        VALUES (${body.userId ?? null}, ${"Atlas AI Travel Conversation"})
        RETURNING id
      `;
      conversationId = rows[0].id;
    }

    await sql`
      INSERT INTO messages (conversation_id, role, content, metadata)
      VALUES (
        ${conversationId},
        'user',
        ${body.userRequest},
        ${JSON.stringify({ source: "web" })}
      )
    `;

    await sql`
      INSERT INTO messages (conversation_id, role, content, metadata)
      VALUES (
        ${conversationId},
        'assistant',
        ${JSON.stringify(plan)},
        ${JSON.stringify({ structured: true })}
      )
    `;

    return NextResponse.json({
      success: true,
      conversationId,
      message: plan.missingInformation.length
        ? "I understand your trip. I need a few details before searching verified inventory."
        : "I understand your trip. The next step is to search verified inventory.",
      plan: {
        destination: plan.destination,
        dates: { checkIn: plan.checkIn, checkOut: plan.checkOut },
        travelers: plan.travelers,
        budget: { amount: plan.budgetAmount, currency: plan.budgetCurrency },
        preferences: plan.preferences,
        nextAction: plan.nextAction,
        dataStatus: plan.dataStatus
      }
    });
  } catch (error) {
    console.error("concierge_error", error);
    return NextResponse.json({ success: false, error: "Invalid request or AI service error." }, { status: 400 });
  }
}