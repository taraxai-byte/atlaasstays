import { NextResponse } from "next/server";
import { sql } from "@/lib/db";

export async function GET() {
  try {
    await sql`SELECT 1`;
    return NextResponse.json({ ok: true, service: "atlaasstays", database: "ok" });
  } catch {
    return NextResponse.json({ ok: false, database: "error" }, { status: 503 });
  }
}