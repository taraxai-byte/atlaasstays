export default function Cancel() {
  return <main className="shell"><section className="hero"><h1>Checkout <span className="gold">cancelled.</span></h1><p>Your checkout was cancelled. No booking should be treated as paid until Stripe confirms it.</p></section></main>;
}